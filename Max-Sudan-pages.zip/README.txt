MAX SUDAN — موقع صفحات تعليمية
الملفات:
- index.html الرئيسية
- subjects.html المواد
- exams.html الاختبارات
- notes.html المذكرات
- support.html الدعم
- subject.html صفحة المادة
- style.css التصميم
- max-reference.png الصورة المرجعية

ارفع كل الملفات إلى مستودع GitHub Pages، وليس ملف ZIP فقط.
